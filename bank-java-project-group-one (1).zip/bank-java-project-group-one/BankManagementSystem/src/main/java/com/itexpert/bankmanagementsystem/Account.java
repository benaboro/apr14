/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.itexpert.bankmanagementsystem;

/**
 *
 * @author Laurence
 */
public class Account {
    private int id;
    private AccountType accountType;
    private double balance;

    public Account(int id, AccountType accountType, double balance) {
        this.id = id;
        this.accountType = accountType;
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Account{" + "id=" + id + ", accountType=" + accountType + ", balance=" + balance + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public AccountType getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    
}
