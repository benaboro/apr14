/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.itexpert.test;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.itexpert.bankmanagementsystem.*;
import java.util.ArrayList;

/**
 *
 * @author Laurence
 */
public class BankTest {

    Bank bank;
    Customer customerIndividual;
    Customer customerBusiness;
    Account accountBusiness;
    Account accountChecking;
    Account accountSavings;
    Employee employeeFull;
    Employee employeeContract;

    public BankTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        accountBusiness = new Account(123, AccountType.BUSINESS, 20000.00);
        accountChecking = new Account(223, AccountType.CHECKING, 2000.00);
        accountSavings = new Account(323, AccountType.SAVINGS, 1000.00);

        employeeFull = new FullTimeEmployee(70000.00f, 12, "John Bob", "jonbo@gmail.com");
        employeeContract = new ContractorEmployee(25.25f, 23, "Jane Doe", "jando@gmail.com");

        ArrayList<Employee> genericEmployees = new ArrayList<>();
        genericEmployees.add(employeeFull);
        genericEmployees.add(employeeContract);
        
        ArrayList<Account> accountsIndividual = new ArrayList<>();
        accountsIndividual.add(accountChecking);
        accountsIndividual.add(accountSavings);

        ArrayList<Account> accountsBusiness = new ArrayList<>();
        accountsBusiness.add(accountBusiness);

        customerIndividual = new Customer(1, "Sally Joe", "1 State St. New York", "sj@gmail.com", CustomerType.INDIVIDUAL, accountsIndividual);
        customerBusiness = new Customer(2, "Millie Sam", "3rd St. New York", "ms@gmail.com", CustomerType.BUSINESS, accountsBusiness);

        ArrayList<Customer> genericCustomers = new ArrayList<>();
        genericCustomers.add(customerIndividual);
        genericCustomers.add(customerBusiness);

        bank = new Bank(1, "Test Bank", "123 Market Blvd New York", "223456789", "tbank@tbank.com", genericEmployees, genericCustomers);

    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    @Test
    public void testBank() {
        assertEquals(bank.getId(), 1);
        assertEquals(bank.getName(), "Test Bank");
        assertEquals(bank.getLocation(), "123 Market Blvd New York");
        assertEquals(bank.getPhone(), "223456789");
        assertEquals(bank.getEmail(), "tbank@tbank.com");
        assertEquals(bank.getEmployees().size(), 2);
        assertEquals(bank.getCustomers().size(), 2);
    }

    @Test
    public void testIndividualCustomer() {
        assertEquals(customerIndividual.getId(), 1);
        assertEquals(customerIndividual.getName(), "Sally Joe");
        assertEquals(customerIndividual.getAddress(), "1 State St. New York");
        assertEquals(customerIndividual.getEmail(), "sj@gmail.com");
        assertEquals(customerIndividual.getCustomerType(), CustomerType.INDIVIDUAL);
        assertEquals(customerIndividual.getAccounts().size(), 2);
        assertEquals(customerIndividual.getAccounts().get(0).getAccountType(), AccountType.CHECKING);
        assertEquals(customerIndividual.getAccounts().get(1).getAccountType(), AccountType.SAVINGS);
    }

    @Test
    public void testBusinessCustomer() {
        assertEquals(customerBusiness.getId(), 2);
        assertEquals(customerBusiness.getName(), "Millie Sam");
        assertEquals(customerBusiness.getAddress(), "3rd St. New York");
        assertEquals(customerBusiness.getEmail(), "ms@gmail.com");
        assertEquals(customerBusiness.getCustomerType(), CustomerType.BUSINESS);
        assertEquals(customerBusiness.getAccounts().size(), 1);
        assertEquals(customerBusiness.getAccounts().get(0).getAccountType(), AccountType.BUSINESS);
    }

    @Test
    public void testCheckingAccount() {
        assertEquals(accountChecking.getId(), 223);
        assertEquals(accountChecking.getAccountType(), AccountType.CHECKING);
        assertEquals(accountChecking.getBalance(), 2000.00);
    }

    @Test
    public void testBusinessAccount() {
        assertEquals(accountBusiness.getId(), 123);
        assertEquals(accountBusiness.getAccountType(), AccountType.BUSINESS);
        assertEquals(accountBusiness.getBalance(), 20000.00);
    }

    @Test
    public void testSavingsAccount() {
        assertEquals(accountSavings.getId(), 323);
        assertEquals(accountSavings.getAccountType(), AccountType.SAVINGS);
        assertEquals(accountSavings.getBalance(), 1000.00);
    }

    @Test
    public void testFulltimeEmployee() {
        assertEquals(employeeFull.getId(), 12);
        assertEquals(employeeFull.getEmail(), "jonbo@gmail.com");
        assertEquals(employeeFull.getName(), "John Bob");
        assertEquals(((FullTimeEmployee)employeeFull).getSalary(), 70000.00f);

    }

    @Test
    public void testContractEmployee() {
        assertEquals(employeeContract.getId(), 23);
        assertEquals(employeeContract.getEmail(), "jando@gmail.com");
        assertEquals(employeeContract.getName(), "Jane Doe");
        assertEquals(((ContractorEmployee)employeeContract).getHourlyRate(), 25.25f);
    }

}
