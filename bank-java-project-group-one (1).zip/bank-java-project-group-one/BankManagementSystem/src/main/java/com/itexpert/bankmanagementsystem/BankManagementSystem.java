/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.itexpert.bankmanagementsystem;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Laurence Xu
 */
public class BankManagementSystem {

    public static void main(String[] args) {
        // TODO code application logic here
        int choice = 0;
        Scanner sc = new Scanner(System.in);
        //empty employee list
        ArrayList<Employee> employees = new ArrayList<>();
        ArrayList<Customer> customers = new ArrayList<>();

        //create a bank with empty employee list
        Bank bank = new Bank(0, null, null, null, null, employees, customers);

        do {
            menu();
            choice = sc.nextInt();
            switch (choice) {
                // Add Bank
                case 1:
                    bank = addBank(sc);
                    break;
                //Show Bank
                case 2:
                    showBank(bank);
                    break;
                // Add Employee
                case 3:
                    Employee emp1 = addEmployee(sc);
                    bank.getEmployees().add(emp1);
                    break;
                // Search Employee by ID
                case 4:
                    searchEmployeeById(sc, bank);
                    break;
                // Save Employee to a file
                case 5:
                    saveEmployee(bank);
                    break;
                // Show Employees
                case 6:
                    showEmployees(bank);
                    break;
                // Add Customer
                case 7:
                    //TODO
                    break;
                // Save Customer to a file
                case 8:
                    //TODO
                    break;
                // Search Cusomer by ID
                case 9:
                    //TODO
                    break;
                // Show Customers
                case 10:
                    //TODO
                    break;
                // Add Account
                case 11:
                    //TODO
                    break;
                // View Accounts
                case 12:
                    //TODO
                    break;
                // Exit Program
                case 13:
                    break;
            }

        } while (choice != 13);

    }

    /**
     * ********Bank Methods*********
     */
    // Creates a bank with no employees, customers or accounts
    public static Bank addBank(Scanner sc) {
        System.out.println("== Add Bank==");

        System.out.println("Enter id");
        int id = sc.nextInt();

        System.out.println("Enter name");
        String name = sc.next();

        System.out.println("Enter location");
        String location = sc.next();

        System.out.println("Enter phone");
        String phone = sc.next();

        System.out.println("Enter email");
        String email = sc.next();

        //empty employee, account, customer list
        ArrayList<Employee> employees = new ArrayList<>();
        ArrayList<Customer> customers = new ArrayList<>();

        Bank bank = new Bank(id, name, location, phone, email, employees, customers);
        return bank;
    }

    public static void showBank(Bank bank) {
        System.out.println("== Bank Details ==");
        System.out.println(bank);
    }

    /**
     * ********Employee Methods*********
     */
    public static Employee addEmployee(Scanner sc) {
        System.out.println("== Add employee==");
        System.out.println("Enter id");
        int id = sc.nextInt();
        System.out.println("Enter name");
        String name = sc.next();

        System.out.println("Enter email");
        String email = sc.next();

        System.out.println("Employee type");
        String type = sc.next();
        Employee emp1 = null;
        if (type.equalsIgnoreCase("fulltime")) {
            //create employee instance with data
            System.out.println("Enter salary");
            float salary = sc.nextFloat();
            emp1 = new FullTimeEmployee(salary, id, name, email);
        } else {
            System.out.println("Enter hourly rate");
            float hourlyrate = sc.nextFloat();
            emp1 = new ContractorEmployee(hourlyrate, id, name, email);
        }
        return emp1;
    }

    // Searches an employee in bank based on ID
    public static void searchEmployeeById(Scanner sc, Bank bank) {
        System.out.println("== Search employee == ");
        System.out.println("Enter employee id ");
        int eid = sc.nextInt();
        boolean found = false;
        for (Employee e : bank.getEmployees()) {
            if (e.getId() == eid) {
                System.out.println(e);
                found = true;
                break;
            }
        }
        if (found == false) {
            System.out.println("For this id - Employee does not exit");
        }
    }

    // Shows all employees currently within bank
    public static void showEmployees(Bank bank) {
        System.out.println("== Employees Details ==");
        for (Employee e : bank.getEmployees()) {
            System.out.print(e + " ");
        }
        System.out.println();
    }

    // Saves employees to file
    public static void saveEmployee(Bank bank) {
        System.out.println("Save Employee");
        try {
            FileWriter fw = new FileWriter("c:\\data\\bank.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("===========Bank ============\n");
            bw.write(bank.getId() + "|" + bank.getName() + "|" + bank.getPhone() + "\n");

            bw.write("===========Employee[s] ============\n");

            for (Employee e : bank.getEmployees()) {

                bw.write(e.getId() + "|" + e.getName() + "|" + e.getEmail());
                if (e instanceof FullTimeEmployee) {
                    bw.write(((FullTimeEmployee) e).getSalary() + "");
                } else {
                    bw.write(((ContractorEmployee) e).getHourlyRate() + "");
                }
                bw.write("\n");
            }
            bw.close();
            fw.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * ********Customer Methods*********
     */
    // Adds Customer to bank
    public static Customer addCustomer(Scanner sc) {
        //TODO
        return null;
    }

    public static void searchCustomerById(Scanner sc, Bank bank) {
        //TODO
    }

    public static void showCustomers(Bank bank) {
        //TODO
    }

    public static void saveCustomer(Bank bank) {
        //TODO
    }

    /**
     * ********Account Methods*********
     */
    public static void addAccount(Scanner sc) {
        //TODO
    }

    public static void showAccounts(Bank bank) {
        //TODO
    }

    public static void searchAccountById(Scanner sc, Bank bank) {
        //TODO
    }

    public static void menu() {
        System.out.println();
        System.out.println("1 for Add Bank");
        System.out.println("2 for Show Bank");
        System.out.println("3 for Add Employee");
        System.out.println("4 for Search Employee by ID");
        System.out.println("5 for Save Employee");
        System.out.println("6 for Show Employees");
        System.out.println("7 for Add Customer");
        System.out.println("8 for Save Customer");
        System.out.println("9 for Search Customer by ID");
        System.out.println("10 for Show Customers");
        System.out.println("11 for Add Account");
        System.out.println("12 for view Accounts");

        System.out.println("13 for Quit");
        System.out.println("Enter your choice  ");
    }
}
