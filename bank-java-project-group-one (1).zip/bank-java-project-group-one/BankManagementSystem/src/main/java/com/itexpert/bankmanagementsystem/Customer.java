/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.itexpert.bankmanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author Laurence
 */
public class Customer {
    private int id;
    private String name;
    private String address;
    private String email;
    private CustomerType customerType;
    private ArrayList<Account> accounts;

    public Customer(int id, String name, String address, String email, CustomerType customerType, ArrayList<Account> accounts) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.email = email;
        this.customerType = customerType;
        this.accounts = accounts;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    public ArrayList<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(ArrayList<Account> accounts) {
        this.accounts = accounts;
    }

    @Override
    public String toString() {
        return "Customer{" + "id=" + id + ", name=" + name + ", address=" + address + ", email=" + email + ", customerType=" + customerType + ", accounts=" + accounts + '}';
    }
    
}
