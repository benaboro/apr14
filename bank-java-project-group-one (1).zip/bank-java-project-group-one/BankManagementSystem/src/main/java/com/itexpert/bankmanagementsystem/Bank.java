/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.itexpert.bankmanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author Laurence Xu
 */
public class Bank {
    private int id;
    private String name;
    private String location;
    private String phone;
    private String email;
    ArrayList<Employee> employees;
    ArrayList<Customer> customers;

    public Bank(int id, String name, String location, String phone, String email, ArrayList<Employee> employees, ArrayList<Customer> customers) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.phone = phone;
        this.email = email;
        this.employees = employees;
        this.customers = customers;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEmployees(ArrayList<Employee> employees) {
        this.employees = employees;
    }

    public void setCustomers(ArrayList<Customer> customers) {
        this.customers = customers;
    }

    @Override
    public String toString() {
        return "Bank{" + "id=" + id + ", name=" + name + ", location=" + location + ", phone=" + phone + ", email=" + email + ", employees=" + employees + ", customers=" + customers + '}';
    }

}
